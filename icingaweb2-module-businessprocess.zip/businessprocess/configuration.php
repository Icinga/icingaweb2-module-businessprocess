<?php

$section = $this->menuSection($this->translate('Reporting'))
    ->add($this->translate('Business Processes'))
    ->setUrl('businessprocess/process/show');

